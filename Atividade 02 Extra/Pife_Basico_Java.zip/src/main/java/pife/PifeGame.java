package pife;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

public final class PifeGame {
    public static final int INITIAL_HAND_SIZE = 9;

    private final List<Player> players;
    private final Deque<Card> drawPile = new ArrayDeque<>();
    private final Deque<Card> discardPile = new ArrayDeque<>();
    private int currentPlayerIndex;
    private Player winner;

    public PifeGame(List<Player> players) {
        validatePlayers(players);
        this.players = new ArrayList<>(players);
        List<Card> deck = createDoubleDeck();
        Collections.shuffle(deck);
        for (int i = 0; i < INITIAL_HAND_SIZE; i++) {
            for (Player player : this.players) {
                player.addCard(deck.remove(0));
            }
        }
        drawPile.addAll(deck);
        discardPile.add(drawPile.removeFirst());
    }

    // Construtor de apoio aos testes, com cartas em ordem conhecida.
    PifeGame(List<Player> players, List<Card> drawCards, Card firstDiscard) {
        validatePlayers(players);
        if (firstDiscard == null) {
            throw new IllegalArgumentException("É necessário ter uma carta descartada.");
        }
        this.players = new ArrayList<>(players);
        drawPile.addAll(Objects.requireNonNull(drawCards));
        discardPile.add(firstDiscard);
    }

    private static void validatePlayers(List<Player> players) {
        if (players == null || players.size() < 2 || players.size() > 8) {
            throw new IllegalArgumentException("O jogo precisa de 2 a 8 jogadores.");
        }
        if (players.stream().anyMatch(Objects::isNull)) {
            throw new IllegalArgumentException("Jogadores não podem ser nulos.");
        }
    }

    public static List<Card> createDoubleDeck() {
        List<Card> deck = new ArrayList<>(104);
        for (int copy = 0; copy < 2; copy++) {
            for (Suit suit : Suit.values()) {
                for (Rank rank : Rank.values()) {
                    deck.add(new Card(rank, suit));
                }
            }
        }
        return deck;
    }

    public List<Player> getPlayers() {
        return List.copyOf(players);
    }

    public Player getCurrentPlayer() {
        return players.get(currentPlayerIndex);
    }

    public Card getTopDiscard() {
        return discardPile.peek();
    }

    public boolean isGameOver() {
        return winner != null;
    }

    public Player getWinner() {
        return winner;
    }

    public Card drawFromDeck() {
        ensureRunning();
        refillIfNecessary();
        Card card = drawPile.pollFirst();
        if (card != null) {
            getCurrentPlayer().addCard(card);
        }
        return card;
    }

    public Card takeDiscard() {
        ensureRunning();
        Card card = discardPile.pollFirst();
        if (card == null) {
            throw new IllegalStateException("Não há carta no descarte.");
        }
        getCurrentPlayer().addCard(card);
        return card;
    }

    public void discard(Card card) {
        ensureRunning();
        Player player = getCurrentPlayer();
        if (player.getHand().size() != 10) {
            throw new IllegalStateException("O descarte deve ocorrer depois de comprar uma carta.");
        }
        if (!player.removeCard(card)) {
            throw new IllegalArgumentException("O jogador não possui essa carta.");
        }
        discardPile.addFirst(card);

        if (player.getHand().size() == 9 && canWin(player.getHand())) {
            winner = player;
            return;
        }
        if (player.getHand().size() != 9) {
            throw new IllegalStateException("Depois do descarte, a mão deve ficar com 9 cartas.");
        }
        moveToNextPlayer();
    }

    public boolean canWin(List<Card> hand) {
        if (hand == null || hand.size() != 9) {
            return false;
        }
        return canPartition(hand, new boolean[hand.size()], 0);
    }

    private boolean canPartition(List<Card> hand, boolean[] used, int usedCount) {
        if (usedCount == hand.size()) {
            return true;
        }
        int firstUnused = firstUnused(used);
        for (int second = firstUnused + 1; second < hand.size(); second++) {
            if (used[second]) {
                continue;
            }
            for (int third = second + 1; third < hand.size(); third++) {
                if (used[third]) {
                    continue;
                }
                List<Card> group = List.of(hand.get(firstUnused), hand.get(second), hand.get(third));
                if (isValidGroup(group)) {
                    used[firstUnused] = true;
                    used[second] = true;
                    used[third] = true;
                    if (canPartition(hand, used, usedCount + 3)) {
                        return true;
                    }
                    used[firstUnused] = false;
                    used[second] = false;
                    used[third] = false;
                }
            }
        }
        return false;
    }

    private static int firstUnused(boolean[] used) {
        for (int i = 0; i < used.length; i++) {
            if (!used[i]) {
                return i;
            }
        }
        return -1;
    }

    public boolean isValidGroup(List<Card> group) {
        if (group == null || group.size() != 3 || new HashSet<>(group).size() != 3) {
            return false;
        }
        boolean sameRank = group.stream().map(Card::rank).distinct().count() == 1;
        boolean differentSuits = group.stream().map(Card::suit).distinct().count() == 3;
        if (sameRank && differentSuits) {
            return true;
        }

        boolean sameSuit = group.stream().map(Card::suit).distinct().count() == 1;
        if (!sameSuit) {
            return false;
        }
        List<Integer> values = group.stream().map(card -> card.rank().getValue()).sorted().toList();
        return (values.equals(List.of(1, 2, 3)) || values.equals(List.of(1, 12, 13))
                || (values.get(1) == values.get(0) + 1 && values.get(2) == values.get(1) + 1));
    }

    private void moveToNextPlayer() {
        currentPlayerIndex = (currentPlayerIndex + 1) % players.size();
    }

    private void refillIfNecessary() {
        if (!drawPile.isEmpty()) {
            return;
        }
        if (discardPile.size() <= 1) {
            return;
        }
        Card top = discardPile.removeFirst();
        List<Card> recycled = new ArrayList<>(discardPile);
        Collections.shuffle(recycled);
        drawPile.addAll(recycled);
        discardPile.clear();
        discardPile.addFirst(top);
    }

    private void ensureRunning() {
        if (isGameOver()) {
            throw new IllegalStateException("A rodada já terminou.");
        }
    }
}
