# Pife básico em Java

## Regras de negócio e casos de teste

**Projeto:** jogo de cartas Pife, executado no terminal.

## Regras implementadas

1. A partida aceita de 2 a 8 participantes. No terminal, uma pessoa joga contra computadores.
2. São usados dois baralhos comuns de 52 cartas, totalizando 104 cartas, sem curingas.
3. Cada participante começa com 9 cartas. O jogador da vez compra uma carta do monte ou a última carta do descarte.
4. Depois da compra, o jogador deve descartar uma carta. A vez passa para o próximo participante.
5. Uma **trinca** é formada por três cartas do mesmo valor e de naipes diferentes.
6. Uma **sequência** é formada por três cartas consecutivas do mesmo naipe. O Ás pode formar A-2-3 ou Q-K-A.
7. Para esta versão simples, o jogador vence quando, depois de descartar, fica com 9 cartas que podem ser divididas em três grupos válidos de três cartas.
8. A rodada termina imediatamente quando alguém vence. Não há pontuação, várias rodadas, coringas, bater fora da vez ou regras de penalidade.

A quantidade de cartas, a distribuição, o objetivo, a compra, o descarte, as trincas, as sequências e o uso do Ás foram baseados em explicações públicas de Pife/Pif Paf da Copag e do MegaJogos. Como existem variações regionais, as regras acima são a definição exata usada pelo código. [1] [2]

## Casos de teste

- **CT01 — Baralho:** verificar que dois baralhos formam 104 cartas.
- **CT02 — Distribuição:** verificar que cada participante começa com 9 cartas.
- **CT03 — Trinca:** aceitar três cartas do mesmo valor e de naipes diferentes.
- **CT04 — Sequência:** aceitar três cartas consecutivas do mesmo naipe.
- **CT05 — Grupo inválido:** rejeitar sequência com naipes diferentes e trinca com carta repetida.
- **CT06 — Mão vencedora:** aceitar uma mão com três grupos válidos.
- **CT07 — Mão inválida:** rejeitar uma mão que não pode ser dividida em três grupos.
- **CT08 — Compra e descarte:** comprar carta, descartar e passar a vez ao próximo participante.
- **CT09 — Vitória:** encerrar a rodada quando o jogador descarta e fica com uma mão vencedora.
- **CT10 — Participantes:** rejeitar uma partida com menos de 2 jogadores.

## Como executar

No Windows, execute `test.bat` para os testes ou `run.bat` para jogar. Em Linux ou macOS, compile com `javac` os arquivos de `src/main/java` e `src/test/java`, depois execute `pife.CardTest` e `pife.PifeGameTest`. Para jogar, execute `pife.Main`.

## Referências

- [Copag — Pif Paf: saiba como jogar e conheça as principais regras](https://blog.copag.com.br/blog/curiosidades/pif-paf-saiba-como-jogar-e-conheca-as-principais-regras)
- [MegaJogos — Regras de Pife/Pif Paf](https://m.megajogos.com.br/pife-pif-paf-online/regras)
