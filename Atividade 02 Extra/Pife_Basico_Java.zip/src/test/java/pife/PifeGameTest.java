package pife;

import java.util.ArrayList;
import java.util.List;

public final class PifeGameTest {
    private static int passed;

    private PifeGameTest() {
    }

    public static void main(String[] args) {
        testPlayersReceiveNineCards();
        testTripleAndSequence();
        testInvalidGroup();
        testWinningHand();
        testDrawAndDiscardAdvanceTurn();
        testWinnerAfterDiscard();
        testInvalidPlayerCount();
        System.out.println("PifeGameTest: " + passed + " testes passaram.");
    }

    private static void testPlayersReceiveNineCards() {
        PifeGame game = new PifeGame(List.of(new Player("A"), new Player("B")));
        check(game.getPlayers().stream().allMatch(p -> p.getHand().size() == 9),
                "Cada participante deve receber 9 cartas.");
        passed++;
    }

    private static void testTripleAndSequence() {
        PifeGame game = emptyGame();
        check(game.isValidGroup(List.of(
                new Card(Rank.SEVEN, Suit.HEARTS), new Card(Rank.SEVEN, Suit.CLUBS),
                new Card(Rank.SEVEN, Suit.SPADES))), "Trinca deve ser válida.");
        check(game.isValidGroup(List.of(
                new Card(Rank.FOUR, Suit.DIAMONDS), new Card(Rank.FIVE, Suit.DIAMONDS),
                new Card(Rank.SIX, Suit.DIAMONDS))), "Sequência deve ser válida.");
        passed++;
    }

    private static void testInvalidGroup() {
        PifeGame game = emptyGame();
        check(!game.isValidGroup(List.of(
                new Card(Rank.FOUR, Suit.DIAMONDS), new Card(Rank.FIVE, Suit.DIAMONDS),
                new Card(Rank.SIX, Suit.HEARTS))), "Cartas de naipes diferentes não formam sequência.");
        check(!game.isValidGroup(List.of(
                new Card(Rank.SEVEN, Suit.HEARTS), new Card(Rank.SEVEN, Suit.HEARTS),
                new Card(Rank.SEVEN, Suit.SPADES))), "Cartas repetidas não devem formar trinca.");
        passed++;
    }

    private static void testWinningHand() {
        PifeGame game = emptyGame();
        List<Card> hand = winningHand();
        check(game.canWin(hand), "Três grupos válidos devem permitir bater.");
        hand.set(8, new Card(Rank.KING, Suit.HEARTS));
        check(!game.canWin(hand), "Uma mão incompleta não deve permitir bater.");
        passed++;
    }

    private static void testDrawAndDiscardAdvanceTurn() {
        Player first = new Player("A");
        Player second = new Player("B");
        for (int i = 0; i < 9; i++) {
            first.addCard(new Card(Rank.values()[i], Suit.HEARTS));
        }
        Card discard = new Card(Rank.FOUR, Suit.HEARTS);
        PifeGame game = new PifeGame(List.of(first, second),
                List.of(new Card(Rank.TWO, Suit.CLUBS)), discard);
        Card extra = game.drawFromDeck();
        check(extra.equals(new Card(Rank.TWO, Suit.CLUBS)), "A carta do monte deve ser comprada.");
        Card toDiscard = first.getHand().get(0);
        game.discard(toDiscard);
        check(game.getCurrentPlayer() == second, "Após descartar, a vez deve passar ao próximo.");
        passed++;
    }

    private static void testWinnerAfterDiscard() {
        Player first = new Player("A");
        Player second = new Player("B");
        List<Card> winHand = winningHand();
        for (Card card : winHand) {
            first.addCard(card);
        }
        first.addCard(new Card(Rank.QUEEN, Suit.CLUBS));
        PifeGame game = new PifeGame(List.of(first, second), List.of(),
                new Card(Rank.NINE, Suit.SPADES));
        Card discard = first.getHand().get(9);
        game.discard(discard);
        check(game.isGameOver(), "A mão com três grupos deve encerrar a rodada.");
        check(game.getWinner() == first, "O jogador que bate deve ser o vencedor.");
        passed++;
    }

    private static void testInvalidPlayerCount() {
        try {
            new PifeGame(List.of(new Player("A")));
            throw new AssertionError("Deveria rejeitar apenas um participante.");
        } catch (IllegalArgumentException expected) {
            passed++;
        }
    }

    private static PifeGame emptyGame() {
        return new PifeGame(List.of(new Player("A"), new Player("B")), List.of(),
                new Card(Rank.ACE, Suit.HEARTS));
    }

    private static List<Card> winningHand() {
        List<Card> hand = new ArrayList<>();
        hand.add(new Card(Rank.ACE, Suit.HEARTS));
        hand.add(new Card(Rank.TWO, Suit.HEARTS));
        hand.add(new Card(Rank.THREE, Suit.HEARTS));
        hand.add(new Card(Rank.FOUR, Suit.CLUBS));
        hand.add(new Card(Rank.FIVE, Suit.CLUBS));
        hand.add(new Card(Rank.SIX, Suit.CLUBS));
        hand.add(new Card(Rank.NINE, Suit.DIAMONDS));
        hand.add(new Card(Rank.NINE, Suit.HEARTS));
        hand.add(new Card(Rank.NINE, Suit.SPADES));
        return hand;
    }

    private static void check(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }
}
