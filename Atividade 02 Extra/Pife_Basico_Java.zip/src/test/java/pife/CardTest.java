package pife;

public final class CardTest {
    private CardTest() {
    }

    public static void main(String[] args) {
        Card card = new Card(Rank.QUEEN, Suit.HEARTS);
        check(card.toString().equals("Q de Copas"), "A carta deve ter uma descrição legível.");
        check(PifeGame.createDoubleDeck().size() == 104, "Dois baralhos devem ter 104 cartas.");
        System.out.println("CardTest: 2 testes passaram.");
    }

    private static void check(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }
}
