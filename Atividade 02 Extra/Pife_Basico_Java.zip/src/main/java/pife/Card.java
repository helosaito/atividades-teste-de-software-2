package pife;

import java.util.Objects;

public record Card(Rank rank, Suit suit) {
    public Card {
        Objects.requireNonNull(rank, "O valor é obrigatório.");
        Objects.requireNonNull(suit, "O naipe é obrigatório.");
    }

    @Override
    public String toString() {
        return rank.getLabel() + " de " + suit.getLabel();
    }
}
