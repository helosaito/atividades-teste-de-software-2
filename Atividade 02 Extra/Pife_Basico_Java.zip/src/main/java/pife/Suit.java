package pife;

public enum Suit {
    HEARTS("Copas"),
    DIAMONDS("Ouros"),
    CLUBS("Paus"),
    SPADES("Espadas");

    private final String label;

    Suit(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
