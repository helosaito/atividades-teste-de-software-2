package pife;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public final class Player {
    private final String name;
    private final List<Card> hand = new ArrayList<>();

    public Player(String name) {
        this.name = Objects.requireNonNull(name, "O nome é obrigatório.").trim();
        if (this.name.isEmpty()) {
            throw new IllegalArgumentException("O nome não pode ficar vazio.");
        }
    }

    public String getName() {
        return name;
    }

    public List<Card> getHand() {
        return List.copyOf(hand);
    }

    void addCard(Card card) {
        hand.add(Objects.requireNonNull(card));
    }

    boolean removeCard(Card card) {
        return hand.remove(card);
    }

    @Override
    public String toString() {
        return name;
    }
}
