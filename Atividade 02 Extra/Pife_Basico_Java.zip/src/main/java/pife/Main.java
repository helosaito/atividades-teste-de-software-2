package pife;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public final class Main {
    private static final Scanner INPUT = new Scanner(System.in);

    private Main() {
    }

    public static void main(String[] args) {
        System.out.println("=== Pife básico ===");
        int count = readInt("Número de participantes (2 a 8): ", 2, 8);
        List<Player> players = new ArrayList<>();
        players.add(new Player("Você"));
        for (int i = 2; i <= count; i++) {
            players.add(new Player("Computador " + i));
        }

        PifeGame game = new PifeGame(players);
        System.out.println("Cada participante recebeu 9 cartas. Você começa.\n");
        while (!game.isGameOver()) {
            Player player = game.getCurrentPlayer();
            System.out.println("\nÚltima carta descartada: " + game.getTopDiscard());
            if (player == players.get(0)) {
                humanTurn(game);
            } else {
                computerTurn(game);
            }
        }
        System.out.println("\nFim da rodada! Vencedor: " + game.getWinner().getName());
    }

    private static void humanTurn(PifeGame game) {
        Player player = game.getCurrentPlayer();
        printHand(player.getHand());
        int source = readInt("Comprar do monte (1) ou do descarte (2)? ", 1, 2);
        Card bought = source == 1 ? game.drawFromDeck() : game.takeDiscard();
        System.out.println("Carta comprada: " + bought);
        printHand(player.getHand());
        int discardIndex = readInt("Número da carta para descartar (1 a 10): ", 1, player.getHand().size());
        Card discarded = player.getHand().get(discardIndex - 1);
        game.discard(discarded);
        if (!game.isGameOver()) {
            System.out.println("Você descartou " + discarded + ".");
        }
    }

    private static void computerTurn(PifeGame game) {
        Player player = game.getCurrentPlayer();
        Card bought = Math.random() < 0.5 ? game.drawFromDeck() : game.takeDiscard();
        List<Card> hand = player.getHand();
        Card discarded = chooseDiscard(hand);
        game.discard(discarded);
        System.out.println(player.getName() + " comprou " + bought + " e descartou " + discarded + ".");
    }

    private static Card chooseDiscard(List<Card> hand) {
        return hand.stream()
                .filter(card -> !card.rank().equals(Rank.ACE))
                .findFirst()
                .orElse(hand.get(0));
    }

    private static void printHand(List<Card> hand) {
        System.out.println("Sua mão:");
        for (int i = 0; i < hand.size(); i++) {
            System.out.println((i + 1) + ") " + hand.get(i));
        }
    }

    private static int readInt(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            try {
                int value = Integer.parseInt(INPUT.nextLine().trim());
                if (value >= min && value <= max) {
                    return value;
                }
            } catch (NumberFormatException ignored) {
                // Solicita novamente.
            }
            System.out.println("Digite um número entre " + min + " e " + max + ".");
        }
    }
}
